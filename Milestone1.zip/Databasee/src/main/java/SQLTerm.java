package main.java;

public class SQLTerm {
	String _strTableName;
	String _strColumnName;
	String _strOperator;
	 Object _objValue ;
	 public SQLTerm(){
		 
	 }
}
